package com.qa.pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.qa.base.StartUpPage;
import com.qa.utils.TestUtil;

public class LoginPage extends StartUpPage {
	
	@FindBy(id="email")
	public WebElement txtusername;
	
	@FindBy(id="pass")
	public WebElement txtpassword;
	
	@FindBy(xpath="//input[@value='Log In']")
	public WebElement btnLogin;
	
	public LoginPage()
	{
		PageFactory.initElements(driver, this);
	}
	
	public HomePage loginToApplication(String username,String password)
	{
		txtusername.clear();
		txtusername.sendKeys(username);
		TestUtil.waitTillElementIsVisible(txtpassword);
		txtpassword.sendKeys(password);
		btnLogin.click();

		return new HomePage();
	}

}
