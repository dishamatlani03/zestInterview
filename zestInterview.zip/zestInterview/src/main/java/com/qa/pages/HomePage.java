package com.qa.pages;

import org.openqa.selenium.Alert;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.qa.base.StartUpPage;
import com.qa.utils.TestUtil;

public class HomePage extends StartUpPage {
	
	@FindBy(xpath="")
	public WebElement txtwriteSomething;
	
	@FindBy(xpath="")
	public WebElement btnPost;
	
	public HomePage()
	{
		PageFactory.initElements(driver, this);
	}
	
	public String postStatusMessage(String message)
	{
		TestUtil.waitTillElementIsVisible(txtwriteSomething);
		txtwriteSomething.sendKeys(message);
		TestUtil.waitTillElementIsVisible(btnPost);
		btnPost.click();
		
		Alert alert = driver.switchTo().alert();
		String successMessage=alert.getText();
		return successMessage;
		
	}

}
