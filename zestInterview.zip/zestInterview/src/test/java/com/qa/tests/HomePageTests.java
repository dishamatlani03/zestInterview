package com.qa.tests;

import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.qa.base.StartUpPage;
import com.qa.pages.HomePage;
import com.qa.pages.LoginPage;
import com.qa.utils.TestUtil;

public class HomePageTests extends StartUpPage{
	
	LoginPage loginPage;
	HomePage homePage;
	
	public  HomePageTests() {
		super();
	}
	
	@BeforeClass
	public void setup()
	{
		initialization();
		loginPage = new LoginPage();
		homePage = loginPage.loginToApplication(prop.getProperty("username"),prop.getProperty("password"));
		
	}
	
	@Test
	public void postStatusMessage()
	{
		String successMessage = homePage.postStatusMessage(prop.getProperty("message"));
		Assert.assertEquals(successMessage, prop.getProperty("expectedsuccmessage"));
		
		
	}
	
	@AfterClass
	public void tearDown()
	{
		TestUtil.quitDriver();
	}

}
