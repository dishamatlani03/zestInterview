package com.qa.utils;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.qa.base.StartUpPage;

public class TestUtil extends StartUpPage {

	public static final long PageLoadTimeout = 20;
	public static final long implicitWait = 20;
	
	
	public static void waitTillElementIsVisible(WebElement element)
	{
		WebDriverWait wait=new WebDriverWait(driver, 20);
		wait.until(ExpectedConditions.visibilityOf(element));
	}
	
}
